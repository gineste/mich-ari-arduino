# CanBusData-arduino (CanBusData_asukiaaa)

A library for arduino to define data types for Can bus.
To use Can bus, use the following library.

[CanBusMCP_asukiaaa](https://github.com/asukiaaa/CanBusMCP-arduino)

# License

MIT

# References
- [acan25125](https://github.com/pierremolinaro/acan2515)
